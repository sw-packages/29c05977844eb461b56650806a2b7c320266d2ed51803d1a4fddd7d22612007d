<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="da">
<context>
    <name>QQuickPlatformDialog</name>
    <message>
        <source>Dialog is an abstract base class</source>
        <translation>Dialog er en abstrakt grundklasse</translation>
    </message>
    <message>
        <source>Cannot create an instance of StandardButton</source>
        <translation>Kan ikke oprette en instans af StandardButton</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2ImagineStylePlugin</name>
    <message>
        <source>Imagine is an attached property</source>
        <translation>Imagine er en tilkoblet egenskab</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2MaterialStylePlugin</name>
    <message>
        <source>Material is an attached property</source>
        <translation>Material er en tilkoblet egenskab</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2UniversalStylePlugin</name>
    <message>
        <source>Universal is an attached property</source>
        <translation>Universal er en tilkoblet egenskab</translation>
    </message>
</context>
</TS>
